def place_order(symbol, order_type, volume):
    print(f"Mock placing order: {order_type} {volume} of {symbol}")