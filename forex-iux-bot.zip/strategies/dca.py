def run_dca_strategy():
    print("Running DCA strategy...")