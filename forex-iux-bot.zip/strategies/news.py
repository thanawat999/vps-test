def run_news_strategy():
    print("Running news trading strategy...")