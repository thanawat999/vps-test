def run_scalping_strategy():
    print("Running scalping strategy...")