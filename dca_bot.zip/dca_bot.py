import time, json, os
from binance.client import Client
from binance.enums import *
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv('API_KEY')
api_secret = os.getenv('API_SECRET')
client = Client(api_key, api_secret)

with open("config.json") as f:
    config = json.load(f)

def get_price(symbol):
    return float(client.get_symbol_ticker(symbol=symbol)['price'])

def buy(symbol, usdt):
    price = get_price(symbol)
    qty = round(usdt / price, 6)
    order = client.order_market_buy(symbol=symbol, quantity=qty)
    return order['fills'][0]['price'], qty

def sell(symbol, qty, target_price):
    while get_price(symbol) < target_price:
        time.sleep(30)
    client.order_market_sell(symbol=symbol, quantity=round(qty, 6))
    print(f"Sold {symbol} at target {target_price}")

def log(msg):
    with open("trade_log.txt", "a") as f:
        f.write(f"{time.ctime()}: {msg}\n")

for symbol in config['symbols']:
    print(f"Running DCA for {symbol}")
    start_price = get_price(symbol)
    orders = []

    for i in range(config['max_orders']):
        buy_price = start_price * (1 - i * config['price_gap'])
        while get_price(symbol) > buy_price:
            time.sleep(30)
        price, qty = buy(symbol, config['base_amount'])
        orders.append((float(price), qty))
        log(f"{symbol} - Buy at {price}")

    avg_price = sum(p * q for p, q in orders) / sum(q for _, q in orders)
    total_qty = sum(q for _, q in orders)
    target = avg_price * (1 + config['take_profit_percent'])

    log(f"{symbol} - Average: {avg_price}, Target: {target}")
    sell(symbol, total_qty, target)
    log(f"{symbol} - Sold at target")
